// Some settings, to be configured using ink global tags
let global_settings = {
    CLEAR_AFTER_CHOICES: true,
    REPLACE_UNDERSCORES: false,
    SKIP_CHOICE_TEXT: false,
}
